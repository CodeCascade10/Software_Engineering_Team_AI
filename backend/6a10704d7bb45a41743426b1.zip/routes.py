# Importing necessary modules
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from auth import (
    authenticate_user,
    create_access_token,
    get_current_user,
    oauth2_scheme,
)
from database import SessionLocal
from models import User

# Creating the router
router = APIRouter()

# Defining the login route
@router.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    db = SessionLocal()
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=30)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

# Defining the users route
@router.get("/users/")
async def read_users(current_user: User = Depends(get_current_user)):
    db = SessionLocal()
    users = db.query(User).all()
    return [{"username": user.username} for user in users]

# Defining the user route
@router.get("/users/me")
async def read_user(current_user: User = Depends(get_current_user)):
    return {"username": current_user.username}