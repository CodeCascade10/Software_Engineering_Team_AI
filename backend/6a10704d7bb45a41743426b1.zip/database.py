# Importing necessary modules
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base

# Defining the database URL
SQLALCHEMY_DATABASE_URL = "sqlite:///example.db"

# Creating the database engine
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Creating the session maker
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)