# Importing necessary modules
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from auth import get_password_hash

# Creating the base class
Base = declarative_base()

# Defining the user model
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)

    def __init__(self, username: str, password: str):
        self.username = username
        self.hashed_password = get_password_hash(password)