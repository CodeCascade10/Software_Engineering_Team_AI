# Import required modules
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from models import User

# Define a database URL
SQLALCHEMY_DATABASE_URL = "sqlite:///database.db"

# Create a database engine
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Create a session maker
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create a base class for models
Base = declarative_base()

# Create the database tables
Base.metadata.create_all(bind=engine)