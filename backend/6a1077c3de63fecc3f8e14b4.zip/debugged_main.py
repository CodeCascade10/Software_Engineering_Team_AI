# Step-by-step analysis of the problem:
1. **Runtime Issues:** The code seems to have some runtime issues, such as the `startup_event` function in `main.py` which disposes the engine before creating the tables. This should be fixed to ensure that the database tables are created successfully.
2. **Syntax Errors:** There are no apparent syntax errors in the provided code.
3. **Import Issues:** The `ModuleNotFoundError: No module named 'routes'` error is likely due to the way the `main.py` file is importing the `router` from `routes.py`. This should be fixed by ensuring that the `routes.py` file is in the same directory as `main.py` or by specifying the correct path.
4. **FastAPI Issues:** The `startup_event` function in `main.py` is using `engine.dispose()` which is not necessary and can cause issues. This should be removed to ensure that the database engine is not disposed of prematurely.
5. **Executable Code:** The code seems to be executable, but it needs some adjustments to ensure that it runs without errors.

# Fixed solution:

# **database.py**

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy.pool import QueuePool

SQLALCHEMY_DATABASE_URL = "sqlite:///database.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    pool_size=10,
    max_overflow=10,
    poolclass=QueuePool,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


# **models.py**

from database import Base
from sqlalchemy import Column, Integer, String

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)

    def __repr__(self):
        return f"User(id={self.id}, username={self.username}, email={self.email})"

class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    description = Column(String)
    user_id = Column(Integer)

    def __repr__(self):
        return f"Task(id={self.id}, title={self.title}, description={self.description})"


# **auth.py**

from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
from database import SessionLocal
from models import User
import os

SECRET_KEY = os.environ.get("SECRET_KEY")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], default="bcrypt")

security = HTTPBearer()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: HTTPAuthorizationCredentials = Depends(security)):
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = username
    except JWTError:
        raise credentials_exception
    db = SessionLocal()
    user = db.query(User).filter(User.username == token_data).first()
    db.close()
    if user is None:
        raise credentials_exception
    return user


# **routes.py**

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from database import SessionLocal
from auth import get_current_user, create_access_token, get_password_hash
from models import User, Task
from typing import List

router = APIRouter()

class UserRequest(BaseModel):
    username: str
    email: str
    password: str

class TaskRequest(BaseModel):
    title: str
    description: str

@router.post("/users/")
async def create_user(user: UserRequest):
    db = SessionLocal()
    if db.query(User).filter(User.username == user.username).first():
        raise HTTPException(status_code=400, detail="Username already exists")
    if db.query(User).filter(User.email == user.email).first():
        raise HTTPException(status_code=400, detail="Email already exists")
    new_user = User(
        username=user.username,
        email=user.email,
        hashed_password=get_password_hash(user.password),
    )
    db.add(new_user)
    db.commit()
    db.close()
    return {"message": "User created successfully"}

@router.post("/tasks/")
async def create_task(task: TaskRequest, user: User = Depends(get_current_user)):
    db = SessionLocal()
    new_task = Task(title=task.title, description=task.description, user_id=user.id)
    db.add(new_task)
    db.commit()
    db.close()
    return {"message": "Task created successfully"}

@router.get("/tasks/", response_model=List[Task])
async def get_tasks(user: User = Depends(get_current_user)):
    db = SessionLocal()
    tasks = db.query(Task).filter(Task.user_id == user.id).all()
    db.close()
    return tasks

@router.get("/tasks/{task_id}")
async def get_task(task_id: int, user: User = Depends(get_current_user)):
    db = SessionLocal()
    task = db.query(Task).filter(Task.id == task_id).filter(Task.user_id == user.id).first()
    db.close()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.put("/tasks/{task_id}")
async def update_task(task_id: int, task: TaskRequest, user: User = Depends(get_current_user)):
    db = SessionLocal()
    task_to_update = db.query(Task).filter(Task.id == task_id).filter(Task.user_id == user.id).first()
    if task_to_update is None:
        raise HTTPException(status_code=404, detail="Task not found")
    task_to_update.title = task.title
    task_to_update.description = task.description
    db.commit()
    db.close()
    return {"message": "Task updated successfully"}

@router.delete("/tasks/{task_id}")
async def delete_task(task_id: int, user: User = Depends(get_current_user)):
    db = SessionLocal()
    task_to_delete = db.query(Task).filter(Task.id == task_id).filter(Task.user_id == user.id).first()
    if task_to_delete is None:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task_to_delete)
    db.commit()
    db.close()
    return {"message": "Task deleted successfully"}


# **main.py**

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import router
from database import engine, Base
import os
import uvicorn
from fastapi.openapi.utils import get_openapi

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

@app.on_event("startup")
async def startup_event():
    Base.metadata.create_all(bind=engine)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))


# Explanation of changes:
*   Removed `engine.dispose()` from `startup_event` in `main.py` to prevent the database engine from being disposed of prematurely.
*   Fixed import issues by ensuring that all necessary modules are imported correctly.
*   Removed unnecessary code and improved code readability.

# Tests and example uses:
To test the API, you can use a tool like `curl` or a API testing tool like Postman. Here are some example commands:
bash
# Create a new user
curl -X POST -H "Content-Type: application/json" -d '{"username": "testuser", "email": "test@example.com", "password": "password"}' http://localhost:8000/users/

# Create a new task
curl -X POST -H "Content-Type: application/json" -d '{"title": "Test Task", "description": "This is a test task"}' -H "Authorization: Bearer <access_token>" http://localhost:8000/tasks/

# Get all tasks
curl -X GET -H "Authorization: Bearer <access_token>" http://localhost:8000/tasks/

# Get a task by id
curl -X GET -H "Authorization: Bearer <access_token>" http://localhost:8000/tasks/1

# Update a task
curl -X PUT -H "Content-Type: application/json" -d '{"title": "Updated Task", "description": "This is an updated task"}' -H "Authorization: Bearer <access_token>" http://localhost:8000/tasks/1

# Delete a task
curl -X DELETE -H "Authorization: Bearer <access_token>" http://localhost:8000/tasks/1