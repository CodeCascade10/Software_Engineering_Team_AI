# Import required modules
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from database import Base
from pydantic import BaseModel

# Define a user model
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)

# Define a user model for API responses
class UserResponse(BaseModel):
    id: int
    username: str