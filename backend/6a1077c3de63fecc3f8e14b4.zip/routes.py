# Import required modules
from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from auth import authenticate, get_current_user
from models import UserResponse
from database import SessionLocal

# Define an OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Create a new API router
router = APIRouter()

# Define a user model for login requests
class LoginRequest(BaseModel):
    username: str
    password: str

# Define a route for user login
@router.post("/auth/login")
async def login(request: LoginRequest):
    user = authenticate(request.username, request.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {"access_token": "your-access-token", "token_type": "bearer"}

# Define a route for getting the current user
@router.get("/users/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return UserResponse(id=current_user.id, username=current_user.username)